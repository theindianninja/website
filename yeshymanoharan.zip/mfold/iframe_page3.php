<?php
    $homepage = file_get_contents('http://unafold.rna.albany.edu/results/0/16May11-00-33-14/16May11-00-33-14_1.ct');
echo $homepage;
?>
hello